select name, team, position, championships 
from coach, coaching_stats 
where coach.id = coaching_stats.coach_id and championships = (select max(championships) from coaching_stats); 
/*
Mason Caldwell|Titans|Head Coach|3
Oliver Scott|Vipers|Head Coach|3
*/

select name, position, team, tds_thrown, interceptions_thrown 
from player, player_stats 
where player.id = player_stats.player_id and player.position = 'Quarterback'; 
/*
Evan Brooks|Quarterback|Lions|2|1
Brayden Miles|Quarterback|Hawks|3|2
Parker Reed|Quarterback|Titans|1|1
Logan Bennett|Quarterback|Vipers|2|1 
*/

select team.name, coach.name, championships
from team, coach, coaching_stats 
where team.name = coach.team and coach.id = coaching_stats.coach_id and championships =0;
/* 
Lions|Megan Ray|0
Titans|Ben Parker|0 
*/

select player.name, player.position, standings.team_name
from player, standings
where player.team = standings.team_name and wins > losses and player.position = 'Quarterback';
/*
Evan Brooks|Quarterback|Lions
Parker Reed|Quarterback|Titans
Logan Bennett|Quarterback|Vipers
*/

select team.name,
(select count(*) from player where player.team = team.name) as num_players
from team;
/*
Hawks|3
Lions|3
Titans|3
Vipers|3
*/