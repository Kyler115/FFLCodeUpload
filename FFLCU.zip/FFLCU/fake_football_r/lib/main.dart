import 'package:fake_football_league/db/database.dart';
import 'package:flutter/material.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';

void main() {
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: RoleSelectionScreen(),
    );
  }
}

class RoleSelectionScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Select Your Role')),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/background.png'), 
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    minimumSize: Size(200, 60), 
                    textStyle: TextStyle(fontSize: 20), 
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
  builder: (context) => MyHomePage(role: 'Coach'),
                      ),
                    );
                  },
                  child: Text('Coach'),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    minimumSize: Size(200, 60),
                    textStyle: TextStyle(fontSize: 20), 
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => MyHomePage(role: 'Team Manager'),
                      ),
                    );
                  },
                  child: Text('Team Manager'),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    minimumSize: Size(200, 60),
                    textStyle: TextStyle(fontSize: 20), 
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => MyHomePage(role: 'Player'),
                      ),
                    );
                  },
                  child: Text('Player'),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    minimumSize: Size(200, 60), 
                    textStyle: TextStyle(fontSize: 20),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => MyHomePage(role: 'FFL Owner'),
                      ),
                    );
                  },
                  child: Text('FFL Owner'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MyHomePage extends StatelessWidget {
  final String role;
  final FFLDatabase database = FFLDatabase.instance;

  MyHomePage({required this.role});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlue,
        title: const Text('FFL'),
      ),
      body: Stack(
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: Container(
              height: 300,
              width: double.infinity,
              color: const Color.fromARGB(255, 150, 212, 241),
              child: Image.asset(
                'assets/FFLogo.png',
                fit: BoxFit.contain,
              ),
            ),
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.only(top: 200.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (role == 'Coach' || role == 'Team Manager' || role == 'FFL Owner') ...[
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        minimumSize: Size(300, 60), 
                        textStyle: TextStyle(fontSize: 20),
                        shape: BeveledRectangleBorder(
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(20),
                            bottomLeft: Radius.circular(20),
                          ),
                        ),
                      ),
                      child: const Text('Add Data'),
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AddDataDialog(role: role);
                          },
                        );
                      },
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        minimumSize: Size(300, 60), 
                        textStyle: TextStyle(fontSize: 20), 
                        shape: BeveledRectangleBorder(
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(20),
                            bottomLeft: Radius.circular(20),
                          ),
                        ),
                      ),
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return DeleteDataDialog(role: role);
                          },
                        );
                      },
                      child: const Text('Delete Data'),
                    ),
                    const SizedBox(height: 20),
                  ],
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      minimumSize: Size(300, 60), 
                      textStyle: TextStyle(fontSize: 20),
                      shape: BeveledRectangleBorder(
                        borderRadius: BorderRadius.only(
                          topRight: Radius.circular(20),
                          bottomLeft: Radius.circular(20),
                        ),
                      ),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ChooseViewScreen(role: role),
                        ),
                      );
                    },
                    child: const Text('View Data'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class AddDataDialog extends StatefulWidget {
  final String role;

  AddDataDialog({required this.role});

  @override
  _AddDataDialogState createState() => _AddDataDialogState();
}

class _AddDataDialogState extends State<AddDataDialog> {
  final FFLDatabase database = FFLDatabase.instance;
  final _formKey = GlobalKey<FormState>();
  String _selectedType = 'Player';
  String? _selectedTeam;
  String? _selectedCoach;
  String? _selectedPlayer;
  String? _selectedHomeTeam;
  String? _selectedAwayTeam;
  List<String> _teams = [];
  List<Map<String, dynamic>> _coaches = [];
  List<Map<String, dynamic>> _players = [];
  final playerNameController = TextEditingController();
  final playerNumberController = TextEditingController();
  final playerPositionController = TextEditingController();
  final teamNameController = TextEditingController();
  final teamConferenceController = TextEditingController();
  final teamLocationController = TextEditingController();
  final teamStadiumController = TextEditingController();
  final teamBudgetController = TextEditingController();
  final coachNameController = TextEditingController();
  final coachPositionController = TextEditingController();
  final tdsController = TextEditingController();
  final scrimmageYardsController = TextEditingController();
  final receptionsController = TextEditingController();
  final carriesController = TextEditingController();
  final tacklesController = TextEditingController();
  final interceptionsController = TextEditingController();
  final forcedFumblesController = TextEditingController();
  final sacksController = TextEditingController();
  final tdsThrownController = TextEditingController();
  final passesThrownController = TextEditingController();
  final completionsController = TextEditingController();
  final interceptionsThrownController = TextEditingController();
  final winsController = TextEditingController();
  final lossesController = TextEditingController();
  final championshipsController = TextEditingController();
  final standingsWinsController = TextEditingController();
  final standingsLossesController = TextEditingController();
  final standingsTiesController = TextEditingController();
  final pointsForController = TextEditingController();
  final pointsAgainstController = TextEditingController();
  final gameDateController = TextEditingController();
  final gameStadiumController = TextEditingController();
  final gameLocationController = TextEditingController();
  final homeScoreController = TextEditingController();
  final awayScoreController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadTeams();
    _loadCoaches();
    _loadPlayers();
  }

  Future<void> _loadTeams() async {
    final teams = await database.getTeams();
    setState(() {
      _teams = teams.map((team) => team['name'] as String).toList();
    });
  }

  Future<void> _loadCoaches() async {
    final coaches = await database.getCoaches();
    setState(() {
      _coaches = coaches;
    });
  }

  Future<void> _loadPlayers() async {
    final players = await database.getPlayers();
    setState(() {
      _players = players;
    });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Add Data'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  value: _selectedType,
                  items: _getDropdownItems(),
                  onChanged: (newValue) {
                    setState(() {
                      _selectedType = newValue!;
                    });
                  },
                  decoration: const InputDecoration(labelText: 'Type'),
                ),
                if (_selectedType == 'Player') ...[
                  _buildTextField(playerNameController, 'Name'),
                  _buildTextField(playerNumberController, 'Number'),
                  _buildTextField(playerPositionController, 'Position'),
                  _buildDropdownButtonFormField(_selectedTeam, _teams, 'Team'),
                ] else if (_selectedType == 'Mentor') ...[
                  _buildDropdownButtonFormField(_selectedCoach, _coaches.map((coach) => coach['name'] as String).toList(), 'Coach'),
                  _buildDropdownButtonFormField(_selectedPlayer, _players.map((player) => player['name'] as String).toList(), 'Player'),
                ] else if (_selectedType == 'Team') ...[
                  _buildTextField(teamNameController, 'Name'),
                  _buildTextField(teamConferenceController, 'Conference'),
                  _buildTextField(teamLocationController, 'Location'),
                  _buildTextField(teamStadiumController, 'Stadium'),
                  _buildTextField(teamBudgetController, 'Budget'),
                ] else if (_selectedType == 'Coach') ...[
                  _buildTextField(coachNameController, 'Name'),
                  _buildTextField(coachPositionController, 'Position'),
                  _buildDropdownButtonFormField(_selectedTeam, _teams, 'Team'),
                ] else if (_selectedType == 'Player Stats') ...[
                  _buildDropdownButtonFormField(_selectedPlayer, _players.map((player) => player['name'] as String).toList(), 'Player'),
                  _buildTextField(tdsController, 'TDs'),
                  _buildTextField(scrimmageYardsController, 'Scrimmage Yards'),
                  _buildTextField(receptionsController, 'Receptions'),
                  _buildTextField(carriesController, 'Carries'),
                  _buildTextField(tacklesController, 'Tackles'),
                  _buildTextField(interceptionsController, 'Interceptions'),
                  _buildTextField(forcedFumblesController, 'Forced Fumbles'),
                  _buildTextField(sacksController, 'Sacks'),
                  _buildTextField(tdsThrownController, 'TDs Thrown'),
                  _buildTextField(passesThrownController, 'Passes Thrown'),
                  _buildTextField(completionsController, 'Completions'),
                  _buildTextField(interceptionsThrownController, 'Interceptions Thrown'),
                ] else if (_selectedType == 'Coach Stats') ...[
                  _buildDropdownButtonFormField(_selectedCoach, _coaches.map((coach) => coach['name'] as String).toList(), 'Coach'),
                  _buildTextField(winsController, 'Wins'),
                  _buildTextField(lossesController, 'Losses'),
                  _buildTextField(championshipsController, 'Championships'),
                ] else if (_selectedType == 'Standings') ...[
                  _buildDropdownButtonFormField(_selectedTeam, _teams, 'Team'),
                  _buildTextField(standingsWinsController, 'Wins'),
                  _buildTextField(standingsLossesController, 'Losses'),
                  _buildTextField(standingsTiesController, 'Ties'),
                  _buildTextField(pointsForController, 'Points For'),
                  _buildTextField(pointsAgainstController, 'Points Against'),
                ] else if (_selectedType == 'Game') ...[
                  _buildTextField(gameDateController, 'Date'),
                  _buildDropdownButtonFormField(_selectedHomeTeam, _teams, 'Home Team'),
                  _buildDropdownButtonFormField(_selectedAwayTeam, _teams, 'Away Team'),
                  _buildTextField(gameStadiumController, 'Stadium'),
                  _buildTextField(gameLocationController, 'Location'),
                  _buildTextField(homeScoreController, 'Home Score'),
                  _buildTextField(awayScoreController, 'Away Score'),
                ],
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () async {
            if (_formKey.currentState!.validate()) {
              await _addData();
              Navigator.of(context).pop();
            }
          },
          child: const Text('Add'),
        ),
      ],
    );
  }

  List<DropdownMenuItem<String>> _getDropdownItems() {
    List<String> types;
    if (widget.role == 'Team Manager') {
      types = ['Player', 'Coach', 'Player Stats', 'Coach Stats'];
    } else if (widget.role == 'Coach') {
      types = ['Player', 'Mentor', 'Player Stats'];
    } else if (widget.role == 'FFL Owner') {
      types = ['Player', 'Team', 'Coach', 'Player Stats', 'Coach Stats', 'Standings', 'Game'];
    } else {
      types = ['Player', 'Team', 'Coach', 'Game'];
    }
    return types.map((String type) {
      return DropdownMenuItem<String>(
        value: type,
        child: Text(type),
      );
    }).toList();
  }

  Widget _buildTextField(TextEditingController controller, String label) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(labelText: label),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter $label';
        }
        return null;
      },
    );
  }

 Widget _buildDropdownButtonFormField(String? selectedValue, List<String> items, String label) {
    return DropdownButtonFormField<String>(
      value: selectedValue,
      items: items.map((String item) {
        return DropdownMenuItem<String>(
          value: item,
          child: Text(item),
        );
      }).toList(),
      onChanged: (newValue) {
        setState(() {
          if (label == 'Team') {
            _selectedTeam = newValue;
          } else if (label == 'Coach') {
            _selectedCoach = newValue;
          } else if (label == 'Player') {
            _selectedPlayer = newValue;
          } else if (label == 'Home Team') {
            _selectedHomeTeam = newValue;
          } else if (label == 'Away Team') {
            _selectedAwayTeam = newValue;
          }
        });
      },
      decoration: InputDecoration(labelText: label),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please select a $label';
        }
        return null;
      },
    );
  }

  Future<void> _addData() async {
    try {
      if (_selectedType == 'Player') {
        await database.addPlayer({
          'name': playerNameController.text,
          'number': playerNumberController.text,
          'position': playerPositionController.text,
          'team': _selectedTeam,
        });
      } else if (_selectedType == 'Team') {
        await database.addTeam({
          'name': teamNameController.text,
          'conference': teamConferenceController.text,
          'location': teamLocationController.text,
          'stadium': teamStadiumController.text,
          'budget': teamBudgetController.text,
        });
      } else if (_selectedType == 'Coach') {
        await database.addCoach({
          'name': coachNameController.text,
          'position': coachPositionController.text,
          'team': _selectedTeam,
        });
      } else if (_selectedType == 'Mentor') {
        final selectedPlayer = _players.firstWhere(
            (player) => player['name'] == _selectedPlayer);
        final selectedCoach = _coaches.firstWhere(
            (coach) => coach['name'] == _selectedCoach);
        await database.assignMentor(
            selectedPlayer['id'], selectedCoach['id']);
      } else if (_selectedType == 'Player Stats') {
        final selectedPlayer = _players.firstWhere(
            (player) => player['name'] == _selectedPlayer);
        await database.updatePlayerStats(selectedPlayer['id'], {
          'tds': tdsController.text,
          'scrimmage_yards': scrimmageYardsController.text,
          'receptions': receptionsController.text,
          'carries': carriesController.text,
          'tackles': tacklesController.text,
          'interceptions': interceptionsController.text,
          'forced_fumbles': forcedFumblesController.text,
          'sacks': sacksController.text,
          'tds_thrown': tdsThrownController.text,
          'passes_thrown': passesThrownController.text,
          'completions': completionsController.text,
          'interceptions_thrown': interceptionsThrownController.text,
        });
      } else if (_selectedType == 'Coach Stats') {
        final selectedCoach = _coaches.firstWhere(
            (coach) => coach['name'] == _selectedCoach);
        final coachId = selectedCoach['id']; 
        print('Selected Coach ID: $coachId');
        await database.updateCoachStats(coachId, {
          'wins': winsController.text,
          'losses': lossesController.text,
          'championships': championshipsController.text,
        });
      } else if (_selectedType == 'Standings') {
        await database.updateStandings(_selectedTeam!, {
          'wins': standingsWinsController.text,
          'losses': standingsLossesController.text,
          'ties': standingsTiesController.text,
          'points_for': pointsForController.text,
          'points_against': pointsAgainstController.text,
        });
      } else if (_selectedType == 'Game') {
        final homeTeam = _teams.firstWhere((team) => team == _selectedHomeTeam);
        final awayTeam = _teams.firstWhere((team) => team == _selectedAwayTeam);
        await database.addGame({
          'date': gameDateController.text,
          'home_team': homeTeam,
          'away_team': awayTeam,
          'stadium': gameStadiumController.text,
          'location': gameLocationController.text,
          'home_score': homeScoreController.text,
          'away_score': awayScoreController.text,
        });
      }
    } catch (e) {
      print('Error adding data: $e');
    }
  }
}
class DeleteDataDialog extends StatefulWidget {
  final String role;

  DeleteDataDialog({required this.role});

  @override
  _DeleteDataDialogState createState() => _DeleteDataDialogState();
}

class _DeleteDataDialogState extends State<DeleteDataDialog> {
  final FFLDatabase database = FFLDatabase.instance;
  String _selectedType = 'Player';
  dynamic _selectedId;
  List<Map<String, dynamic>> _items = [];

  @override
  void initState() {
    super.initState();
    _loadItems();
  }

  Future<void> _loadItems() async {
    List<Map<String, dynamic>> items = [];
    if (_selectedType == 'Player') {
      items = await database.getPlayers();
    } else if (_selectedType == 'Team') {
      items = await database.getTeams();
    } else if (_selectedType == 'Coach') {
      items = await database.getCoaches();
    } else if (_selectedType == 'Game') {
      items = await database.getGames();
    } else if (_selectedType == 'Player Stats') {
      items = await database.getPlayerStats();
    } else if (_selectedType == 'Coach Stats') {
      items = await database.getCoachStats();
    } else if (_selectedType == 'Mentor') {
      items = await database.getMentors();
    } else if (_selectedType == 'Standings') {
      items = await database.getStandings();
    }
    setState(() {
      _items = items;
      _selectedId = _items.isNotEmpty ? getSelectedId(_items.first) : null;
      print('Loaded items: $_items');
      print('Selected ID: $_selectedId');
    });
  }

  dynamic getSelectedId(Map<String, dynamic> item) {
    if (_selectedType == 'Game') {
      return '${item['date']}_${item['home_team']}';
    } else if (_selectedType == 'Coach Stats') {
      return item['coach_id'];
    } else {
      return item['id'] ?? item['name'] ?? item['player_id'] ?? item['team_name'];
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Delete Data'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<String>(
              value: _selectedType,
              items: _getDropdownItems(),
              onChanged: (newValue) {
                setState(() {
                  _selectedType = newValue!;
                  _loadItems();
                });
              },
              decoration: const InputDecoration(labelText: 'Type'),
            ),
            if (_items.isNotEmpty) ...[
              DropdownButtonFormField<dynamic>(
                value: _selectedId,
                items: _items.map((item) {
                  return DropdownMenuItem<dynamic>(
                    value: getSelectedId(item),
                    child: Text(_getItemDisplayText(item)),
                  );
                }).toList(),
                onChanged: (newValue) {
                  setState(() {
                    _selectedId = newValue!;
                    print('Selected ID changed: $_selectedId');
                  });
                },
                decoration: const InputDecoration(labelText: 'Item'),
              ),
            ] else ...[
              const Text('No items found'),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () async {
            if (_selectedId != null) {
              await _deleteSelectedItem();
              Navigator.of(context).pop();
            }
          },
          child: const Text('Delete'),
        ),
      ],
    );
  }

  List<DropdownMenuItem<String>> _getDropdownItems() {
    List<String> types;
    if (widget.role == 'Team Manager') {
      types = ['Player', 'Team', 'Coach', 'Player Stats', 'Coach Stats'];
    } else if (widget.role == 'Coach') {
      types = ['Player', 'Mentor', 'Player Stats'];
    } else if (widget.role == 'FFL Owner') {
      types = ['Player', 'Team', 'Coach', 'Game', 'Standings', 'Player Stats', 'Coach Stats', 'Mentor'];
    } else {
      types = ['Player', 'Team', 'Coach', 'Game'];
    }
    return types.map((String type) {
      return DropdownMenuItem<String>(
        value: type,
        child: Text(type),
      );
    }).toList();
  }

  String _getItemDisplayText(Map<String, dynamic> item) {
    if (_selectedType == 'Game') {
      return '${item['date']} - ${item['home_team']} vs ${item['away_team']}';
    } else if (_selectedType == 'Coach Stats') {
      return 'Coach ID: ${item['coach_id']}, Wins: ${item['wins']}, Losses: ${item['losses']}, Championships: ${item['championships']}';
    } else {
      return item['name'] ?? item['date'] ?? item['player_id']?.toString() ?? item['team_name'] ?? '';
    }
  }

  Future<void> _deleteSelectedItem() async {
    if (_selectedType == 'Player') {
      await database.deletePlayer(_selectedId);
    } else if (_selectedType == 'Team') {
      await database.deleteTeam(_selectedId);
    } else if (_selectedType == 'Coach') {
      await database.deleteCoach(_selectedId);
    } else if (_selectedType == 'Game' && widget.role != 'Viewer') {
      var parts = _selectedId.split('_');
      await database.deleteGame(parts[0], parts[1]);
    } else if (_selectedType == 'Player Stats') {
      await database.deletePlayerStats(_selectedId);
    } else if (_selectedType == 'Coach Stats') {
      await database.deleteCoachStats(_selectedId);
    } else if (_selectedType == 'Mentor') {
      await database.deleteMentor(_selectedId);
    } else if (_selectedType == 'Standings') {
      await database.deleteStandings(_selectedId);
    }
  }
}

class ChooseViewScreen extends StatefulWidget {
  final String role;

  ChooseViewScreen({required this.role});

  @override
  _ChooseViewScreenState createState() => _ChooseViewScreenState();
}

class _ChooseViewScreenState extends State<ChooseViewScreen> {
  String? _hoveredButton;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Choose Data to View'),
      ),
      body: Row(
        children: [
          Expanded(
            flex: 1,
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  _buildButton(context, 'Players'),
                  _buildButton(context, 'Teams'),
                  _buildButton(context, 'Coaches'),
                  _buildButton(context, 'Games'),
                  _buildButton(context, 'Player Stats'),
                  _buildButton(context, 'Coach Stats'),
                  _buildButton(context, 'Standings'),
                  _buildButton(context, 'Mentors'),
                ],
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Container(
              color: Colors.grey[200],
              child: _hoveredButton != null
                  ? Image.asset(
                      'assets/${_hoveredButton!.replaceAll(' ', '')}.png',
                      fit: BoxFit.contain,
                      errorBuilder: (context, error, stackTrace) {
                        return Image.asset(
                          'assets/${_hoveredButton!.replaceAll(' ', '')}.jpeg',
                          fit: BoxFit.contain,
                          errorBuilder: (context, error, stackTrace) {
                            return Center(child: Text('Image not found'));
                          },
                        );
                      },
                    )
                  : Container(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildButton(BuildContext context, String dataType) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: MouseRegion(
        onEnter: (_) => setState(() => _hoveredButton = dataType),
        onExit: (_) => setState(() => _hoveredButton = null),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            minimumSize: Size(300, 60), 
            textStyle: TextStyle(fontSize: 20), 
            shape: BeveledRectangleBorder(
              borderRadius: BorderRadius.only(
                topRight: Radius.circular(20),
    bottomLeft: Radius.circular(20),
              ),
            ),
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ViewDataScreen(
                  dataType: dataType,
                  role: widget.role,
                ),
              ),
            );
          },
          child: Text(dataType),
        ),
      ),
    );
  }
}

class ViewDataScreen extends StatelessWidget {
  final String dataType;
  final String role;

  ViewDataScreen({required this.dataType, required this.role});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('View $dataType'),
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _fetchData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No data found'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                final item = snapshot.data![index];
                return ListTile(
                  title: Text(item['name']?.toString() ?? item['date']?.toString() ?? ''),
                  subtitle: Text(item.toString()),
                );
              },
            );
          }
        },
      ),
    );
  }

  Future<List<Map<String, dynamic>>> _fetchData() async {
    final database = FFLDatabase.instance;
    if (dataType == 'Players') {
      return await database.getPlayers();
    } else if (dataType == 'Teams') {
      return await database.getTeams();
    } else if (dataType == 'Coaches') {
      return await database.getCoaches();
    } else if (dataType == 'Games') {
      return await database.getGames();
    } else if (dataType == 'Player Stats') {
      return await database.getPlayerStats();
    } else if (dataType == 'Coach Stats') {
      return await database.getCoachStats();
    } else if (dataType == 'Standings') {
      return await database.getStandings();
    } else if (dataType == 'Mentors') {
      return await database.getMentors();
    } else {
      throw Exception('Unknown data type');
    }
  }
}