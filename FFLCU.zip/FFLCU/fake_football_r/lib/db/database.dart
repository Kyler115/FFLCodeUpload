import 'package:flutter/services.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'dart:io';

class FFLDatabase {
  static final FFLDatabase instance = FFLDatabase._init();
  static Database? _database;

  FFLDatabase._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('ffl_database.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    // Check if the database exists
    final exists = await databaseExists(path);
    if (!exists) {
      // If it doesn't exist, copy from assets
      try {
        await Directory(dirname(path)).create(recursive: true);
        // Copy from asset
        ByteData data = await rootBundle.load('assets/ffl_database.db');
        List<int> bytes = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
        // Write and flush the bytes
        await File(path).writeAsBytes(bytes, flush: true);
        print('Database copied from assets');
      } catch (e) {
        print('Error copying database: $e');
      }
    } else {
      print('Database already exists at $path');
    }
    return await openDatabase(path);
  }

  Future<List<Map<String, dynamic>>> getPlayers() async {
    final db = await instance.database;
    return await db.query('player');
  }

  Future<List<Map<String, dynamic>>> getTeams() async {
    final db = await instance.database;
    return await db.query('team');
  }

  Future<List<Map<String, dynamic>>> getCoaches() async {
    final db = await instance.database;
    return await db.query('coach');
  }

  Future<List<Map<String, dynamic>>> getGames() async {
    final db = await instance.database;
    return await db.query('game');
  }

  Future<List<Map<String, dynamic>>> getPlayerStats() async {
    final db = await instance.database;
    return await db.query('player_stats');
  }

  Future<List<Map<String, dynamic>>> getCoachStats() async {
    final db = await instance.database;
    return await db.query('coaching_stats');
  }

  Future<List<Map<String, dynamic>>> getStandings() async {
    final db = await instance.database;
    return await db.query('standings');
  }

  Future<List<Map<String, dynamic>>> getMentors() async {
    final db = await instance.database;
    return await db.query('mentor');
  }

  Future<void> addPlayer(Map<String, dynamic> player) async {
    final db = await instance.database;
    await db.insert('player', player);
    await db.insert('player_stats', {'player_id': player['id']}); 
  }

  Future<void> addTeam(Map<String, dynamic> team) async {
    final db = await instance.database;
    await db.insert('team', team);
  }

  Future<void> addCoach(Map<String, dynamic> coach) async {
    final db = await instance.database;
    await db.insert('coach', coach);
    await db.insert('coaching_stats', {'coach_id': coach['id']});
  }

  Future<void> addGame(Map<String, dynamic> game) async {
    final db = await instance.database;
    await db.insert('game', game);
  }

  Future<void> updatePlayer(int id, Map<String, dynamic> player) async {
    final db = await instance.database;
    await db.update('player', player, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> updatePlayerStats(int playerId, Map<String, dynamic> stats) async {
    final db = await instance.database;
    await db.update('player_stats', stats, where: 'player_id = ?', whereArgs: [playerId]);
  }

  Future<void> updateCoachStats(int id, Map<String, dynamic> stats) async {
    final db = await instance.database;
    await db.update('coaching_stats', stats, where: 'coach_id = ?', whereArgs: [id]);
  }

  Future<void> updateStandings(String teamName, Map<String, dynamic> standings) async {
    final db = await instance.database;
    await db.update('standings', standings, where: 'team_name = ?', whereArgs: [teamName]);
  }

  Future<void> updateGame(String date, String homeTeam, Map<String, dynamic> game) async {
    final db = await instance.database;
    await db.update('game', game, where: 'date = ? AND home_team = ?', whereArgs: [date, homeTeam]);
  }

  Future<void> deletePlayer(int id) async {
    final db = await instance.database;
    await db.delete('player', where: 'id = ?', whereArgs: [id]);
    await db.delete('player_stats', where: 'player_id = ?', whereArgs: [id]);
    await db.delete('mentor', where: 'player_id = ?', whereArgs: [id]);
  }

  Future<void> deleteTeam(String name) async {
    final db = await instance.database;
    await db.delete('team', where: 'name = ?', whereArgs: [name]);
    await db.delete('standings', where: 'team_name = ?', whereArgs: [name]);
  }

  Future<void> deleteCoach(int id) async {
    final db = await instance.database;
    await db.delete('coach', where: 'id = ?', whereArgs: [id]);
    await db.delete('coaching_stats', where: 'coach_id = ?', whereArgs: [id]);
    await db.delete('mentor', where: 'coach_id = ?', whereArgs: [id]);
  }

  Future<void> deleteGame(String date, String homeTeam) async {
    final db = await instance.database;
    await db.delete('game', where: 'date = ? AND home_team = ?', whereArgs: [date, homeTeam]);
  }

  Future<void> assignMentor(int playerId, int coachId) async {
    final db = await instance.database;
    await db.insert('mentor', {'player_id': playerId, 'coach_id': coachId});
  }

  Future<void> deleteStandings(String teamName) async {
    final db = await instance.database;
    await db.delete('standings', where: 'team_name = ?', whereArgs: [teamName]);
  }

  Future<void> deletePlayerStats(int playerId) async {
    final db = await instance.database;
    await db.delete('player_stats', where: 'player_id = ?', whereArgs: [playerId]);
  }

  Future<void> deleteCoachStats(int coachId) async {
    final db = await instance.database;
    await db.delete('coaching_stats', where: 'coach_id = ?', whereArgs: [coachId]);
  }

  Future<void> deleteMentor(int playerId) async {
    final db = await instance.database;
    await db.delete('mentor', where: 'player_id = ?', whereArgs: [playerId]);
  }
}