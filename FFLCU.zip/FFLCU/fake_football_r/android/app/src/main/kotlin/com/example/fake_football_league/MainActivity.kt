package com.example.fake_football_league

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
