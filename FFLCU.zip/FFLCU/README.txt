TO RUN THE CODE:
After Cloning from the git repository, simply:

1.) Open fake_football_r with vscode or another editor capable of handling flutter
2.) Create a new terminal if one hasn't been generated
3.) Do flutter clean, then flutter pub get, then flutter run.
4.) When prompted for which output to use, press 1 for windows.
5.) You should be set to explore the GUI! 


The only reason the code would not run would be because of version issues, which if that is the case i have attached the output of my flutter doctor --verbose command:
============================================================================================
[√] Flutter (Channel stable, 3.24.5, on Microsoft Windows [Version 10.0.22631.4541], locale en-US)
    • Flutter version 3.24.5 on channel stable at C:\Users\kyler\flutter
    • Upstream repository https://github.com/flutter/flutter.git
    • Framework revision dec2ee5c1f (3 weeks ago), 2024-11-13 11:13:06 -0800
    • Engine revision a18df97ca5
    • Dart version 3.5.4
    • DevTools version 2.37.3

[√] Windows Version (Installed version of Windows is version 10 or higher)

[√] Android toolchain - develop for Android devices (Android SDK version 34.0.0)
    • Android SDK at C:\Users\kyler\AppData\Local\Android\sdk
    • Platform android-34, build-tools 34.0.0
    • Java binary at: C:\Program Files\Java\jdk-17\bin\java
    • Java version Java(TM) SE Runtime Environment (build 17.0.12+8-LTS-286)
    • All Android licenses accepted.

[√] Chrome - develop for the web
    • Chrome at C:\Program Files\Google\Chrome\Application\chrome.exe

[√] Visual Studio - develop Windows apps (Visual Studio Community 2022 17.10.3)
    • Visual Studio at C:\Program Files\Microsoft Visual Studio\2022\Community
    • Visual Studio Community 2022 version 17.10.35013.160
    • Windows 10 SDK version 10.0.22621.0

[√] Android Studio (version 2024.2)
    • Android Studio at C:\Program Files\Android\Android Studio
    • Flutter plugin can be installed from:
       https://plugins.jetbrains.com/plugin/9212-flutter
    • Dart plugin can be installed from:
       https://plugins.jetbrains.com/plugin/6351-dart
    • Java version OpenJDK Runtime Environment (build 21.0.3+-12282718-b509.11)

[√] VS Code (version 1.95.3)
    • VS Code at C:\Users\kyler\AppData\Local\Programs\Microsoft VS Code
    • Flutter extension version 3.102.0

[√] Connected device (3 available)
    • Windows (desktop) • windows • windows-x64    • Microsoft Windows [Version 10.0.22631.4541]
    • Chrome (web)      • chrome  • web-javascript • Google Chrome 131.0.6778.86
    • Edge (web)        • edge    • web-javascript • Microsoft Edge 131.0.2903.70

[√] Network resources
    • All expected network resources are available.

• No issues found!
============================================================================================

Once The code Runs, There are 4 roles, Player, Coach, Team Manager, and FFL Owner. Each role has different abilities on what they can add and delete in the database. For a more detailed explanation, see the AUI section in the report. 
 
The only possible issue is updating a new teams standings, which you may have to restart the app to view the changes made. Besides that everything seems to work great!

Any changes made in the GUI if saved, and if not cleaned (Not running flutter clean because that would delete the changed database), can be viewed in a database viewer by simply going to get the new database file from .dart_tool\sqflite_common_ffi\databases\ffl_database.db and plugging it in. https://www.db-book.com/university-lab-dir/sqljs.html Is very helpful for short term viewing. 

The default database is in assets, which is pulled and accessed as well as edited by the GUI using the sqflite plugin for flutter. It is also in the seperate folder labeled database in the git repository, as well are some test queries. To run test queries, simply using SQL Lite, or the link above. 
**NOTE, THIS DATABASE FILE IS NOT ATTACHED TO THE CODE IN FFL, THE DEFAULT DATABASE IN FFL IS IN THE ASSETS FOLDER, AND THE DATABASE EDITIED IS IN .dart_tool\sqflite_common_ffi\databases\ffl_database.db**

AI STATEMENT:
AI was used for the repetitive tasks and for help in debugging. For example, Each and every possible add data dialog and delete data dialog for each role. This was a simple task for AI, and would have taken a very long time by a human. I finished the player, coach, and team add in first and then plugged it in to AI to make the corresponding adds/ deletes for the corresponding roles. I then went in behind it and fixed anything messed up, which most of the time was padding issues of buttons or not loading pictures in correctly. For debugging, the main issues were issues regarding padding because that is just how flutter is. 

The SQFLITE plugin was very easy to use, and the Database helper file made it very straight forward. One of the only issues was getting the view to update in real time.

For any questions, issues, concerns, help, email kvanca1@lsu.edu or kyler.vancamp@gmail.com. 

Enjoy:)